/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ex_12;

/**
 *
 * @author Londiwe Nkwanyana
 */
public class ShoppingCart {
    public static void main(String[] args){

	// instantiate a Shirt object and call display() on the object reference
        Shirt shirt = new Shirt(25.99, 'M', 'P');
        shirt.display();
    }
}

        


